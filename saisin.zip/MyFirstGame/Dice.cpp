#include "Dice.h"
#include <string>

Dice::Dice()
{
}

Dice::~Dice()
{
}

HRESULT Dice::Initialize()
{
	return Quad::Initialize();

	
}

void Dice::Draw(XMMATRIX& worldMatrix)
{
	QuadData data[] = {
		QuadData({ 0.0f, 0.0f, 0.0f }, { 0.0f, 0.0f, 0.0f }, { 1.0f, 1.0f }),
		QuadData({ 1.0f, 1.0f, 1.0f }, { 45.0f, 45.0f, 45.0f }, { 1.0f, 1.0f }),
		QuadData({ -1.0f, -1.0f, -1.0f }, { -45.0f, -45.0f, -45.0f }, { 1.0f, 1.0f })
	};
	for (const auto& d : data)
	{
		XMMATRIX mat = XMMatrixTranslation(d.position.x, d.position.y, d.position.z) *
			XMMatrixRotationRollPitchYaw(XMConvertToRadians(d.rotate.x), XMConvertToRadians(d.rotate.y), XMConvertToRadians(d.rotate.z)) *
			worldMatrix;
		Quad::Draw(mat);
	}
}
